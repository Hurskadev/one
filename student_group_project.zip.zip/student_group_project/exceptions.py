class GroupLimitError(Exception):
    pass
