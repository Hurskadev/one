from student import Student
from group import Group
from exceptions import GroupLimitError

st1 = Student('Male', 30, 'Steve', 'Jobs', 'AN142')
st2 = Student('Female', 25, 'Liza', 'Taylor', 'AN145')

gr = Group('PD1')
gr.add_student(st1)
gr.add_student(st2)

print(gr)

assert gr.find_student('Jobs') == st1  # 'Steve Jobs'
assert gr.find_student('Jobs2') is None
assert isinstance(gr.find_student('Jobs'), Student)

gr.delete_student('Taylor')
print(gr)

gr.delete_student('Taylor')

for i in range(3, 11):
    gr.add_student(Student('Male', 20 + i, f'Name{i}', f'Surname{i}', f'RB{i}'))

try:
    gr.add_student(Student('Female', 25, 'Extra', 'Student', 'RB999'))
except GroupLimitError as e:
    print(f'Error: {e}')
